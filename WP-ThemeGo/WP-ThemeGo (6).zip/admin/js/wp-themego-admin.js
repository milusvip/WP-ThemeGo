(function($) {
    'use strict';

    $(document).ready(function() {
        // 菜单交互
        $('.menu-item.has-submenu > a').on('click', function(e) {
            e.preventDefault();
            const menuItem = $(this).parent();
            const firstSubmenuItem = menuItem.find('.submenu li:first-child a');
            
            // 如果菜单项未激活，则激活并显示第一个子菜单内容
            if (!menuItem.hasClass('active')) {
                // 关闭其他展开的菜单
                $('.menu-item.has-submenu').not(menuItem).removeClass('active');
                // 激活当前菜单
                menuItem.addClass('active');
                // 触发第一个子菜单项的点击事件
                if (firstSubmenuItem.length) {
                    firstSubmenuItem.trigger('click');
                }
            }
            // 如果菜单项已经激活，则保持当前状态
        });

        // 内容区域切换
        $('.menu-item a, .submenu a').on('click', function(e) {
            e.preventDefault();
            const target = $(this).attr('href');
            const menuItem = $(this).parent();
            
            if (target === '#') return;

            // 如果点击的是子菜单项
            if (menuItem.closest('.submenu').length > 0) {
                // 移除所有菜单项的激活状态
                $('.menu-item a, .submenu li').removeClass('active');
                // 激活当前子菜单项
                menuItem.addClass('active');
                // 保持父菜单项的展开状态
                menuItem.closest('.menu-item.has-submenu').addClass('active');

                // 显示对应的内容区域
                $('.content-section').removeClass('active');
                $(target).addClass('active');
            }
            // 如果点击的是没有子菜单的主菜单项
            else if (!menuItem.hasClass('has-submenu')) {
                // 移除所有菜单项的激活状态
                $('.menu-item a, .submenu li').removeClass('active');
                menuItem.addClass('active');
                // 关闭所有展开的子菜单
                $('.menu-item.has-submenu').removeClass('active');

                // 显示对应的内容区域
                $('.content-section').removeClass('active');
                $(target).addClass('active');
            }
        });

        // 搜索功能
        $('.search-box input').on('keyup', function() {
            const searchTerm = $(this).val().toLowerCase();
            
            // 在主题列表中搜索
            $('.theme-card').each(function() {
                const themeName = $(this).find('h3').text().toLowerCase();
                const themeDesc = $(this).find('p').text().toLowerCase();
                
                if (themeName.includes(searchTerm) || themeDesc.includes(searchTerm)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });

        // 保存按钮点击事件
        $('.save-button').on('click', function() {
            // 获取当前激活的内容区域
            const activeSection = $('.content-section.active');
            const sectionId = activeSection.attr('id');
            const button = $(this);
            
            // 根据不同的内容区域收集不同的设置
            let settings = {};
            let type = '';
            
            switch (sectionId) {
                case 'site-protection':
                    type = 'protection';
                    // 收集网站防护设置
                    settings = {
                        disable_right_click: activeSection.find('input[name="disable_right_click"]').prop('checked'),
                        disable_f12: activeSection.find('input[name="disable_f12"]').prop('checked'),
                        disable_dev_shortcuts: activeSection.find('input[name="disable_dev_shortcuts"]').prop('checked'),
                        disable_view_source: activeSection.find('input[name="disable_view_source"]').prop('checked'),
                        disable_save: activeSection.find('input[name="disable_save"]').prop('checked'),
                        disable_print: activeSection.find('input[name="disable_print"]').prop('checked'),
                        disable_copy_paste: activeSection.find('input[name="disable_copy_paste"]').prop('checked'),
                        disable_drag: activeSection.find('input[name="disable_drag"]').prop('checked'),
                        disable_select: activeSection.find('input[name="disable_select"]').prop('checked'),
                        disable_console: activeSection.find('input[name="disable_console"]').prop('checked')
                    };
                    break;
                default:
                    showNotification('请先选择要保存的设置项', 'error');
                    return;
            }
            
            // 禁用按钮并显示加载状态
            button.prop('disabled', true).addClass('updating-message');
            
            // 发送AJAX请求
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'wp_themego_save_settings',
                    nonce: wpThemeGoAdmin.nonce,
                    type: type,
                    settings: settings
                },
                success: function(response) {
                    if (response.success) {
                        showNotification(response.data.message || '设置已保存', 'success');
                    } else {
                        showNotification(response.data.message || '保存失败，请重试', 'error');
                    }
                },
                error: function() {
                    showNotification('保存失败，请重试', 'error');
                },
                complete: function() {
                    // 恢复按钮状态
                    button.prop('disabled', false).removeClass('updating-message');
                }
            });
        });

        // 添加通知函数
        function showNotification(message, type = 'success') {
            // 移除现有通知
            $('.wp-themego-notification').remove();
            
            // 创建新通知
            const notification = $('<div>', {
                class: `wp-themego-notification ${type}`,
                text: message
            });
            
            // 添加到页面
            $('body').append(notification);
            
            // 显示通知
            setTimeout(() => {
                notification.addClass('show');
            }, 10);
            
            // 3秒后隐藏
            setTimeout(() => {
                notification.removeClass('show');
                setTimeout(() => {
                    notification.remove();
                }, 300);
            }, 3000);
        }

        // 主题激活处理
        $('.activate-theme').on('click', function(e) {
            e.preventDefault();
            
            const button = $(this);
            const themeStylesheet = button.data('theme');
            
            if (!themeStylesheet) {
                return;
            }

            // 在激活过程中禁用按钮
            button.prop('disabled', true);
            button.text('正在启用...');

            // 发送AJAX请求激活主题
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'wp_themego_activate_theme',
                    theme: themeStylesheet,
                    nonce: wpThemeGoAdmin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // 重新加载页面以显示更新后的主题状态
                        window.location.reload();
                    } else {
                        alert(response.data.message || '主题启用失败，请重试。');
                        button.prop('disabled', false);
                        button.text('启用主题');
                    }
                },
                error: function() {
                    alert('主题启用失败，请重试。');
                    button.prop('disabled', false);
                    button.text('启用主题');
                }
            });
        });

        // 初始化：根据URL hash激活对应的菜单项
        const hash = window.location.hash;
        if (hash) {
            const targetMenuItem = $(`.menu-item a[href="${hash}"], .submenu a[href="${hash}"]`);
            if (targetMenuItem.length) {
                targetMenuItem.trigger('click');
            }
        } else {
            // 如果没有hash，默认激活第一个菜单项的第一个子菜单
            const firstSubmenuItem = $('.menu-item.has-submenu:first .submenu li:first-child a');
            if (firstSubmenuItem.length) {
                firstSubmenuItem.trigger('click');
            }
        }

        // 移动端菜单处理
        // 添加遮罩层
        $('body').append('<div class="sidebar-overlay"></div>');
        
        // 点击菜单按钮
        $('.mobile-menu-toggle').on('click', function() {
            $('.wp-themego-sidebar, .sidebar-overlay').addClass('active');
            $('body').css('overflow', 'hidden');
        });
        
        // 点击遮罩层关闭菜单
        $('.sidebar-overlay').on('click', function() {
            $('.wp-themego-sidebar, .sidebar-overlay').removeClass('active');
            $('body').css('overflow', '');
        });
        
        // 监听窗口大小变化
        $(window).on('resize', function() {
            if ($(window).width() > 782) {
                $('.wp-themego-sidebar, .sidebar-overlay').removeClass('active');
                $('body').css('overflow', '');
            }
        });

        // 搜索框切换
        $('.search-toggle').on('click', function(e) {
            e.preventDefault();
            $('.search-box').addClass('active').find('input').focus();
        });

        $('.search-close').on('click', function(e) {
            e.preventDefault();
            $('.search-box').removeClass('active');
        });

        // 点击外部关闭搜索框
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.search-box, .search-toggle').length) {
                $('.search-box').removeClass('active');
            }
        });
    });

})(jQuery); 