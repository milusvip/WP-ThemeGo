<?php
/**
 * 提供插件的管理界面视图
 *
 * 用于标记插件管理界面的外观
 */
?>

<div class="wp-themego-admin-wrapper">
    <!-- 顶部栏 -->
    <div class="wp-themego-header">
        <div class="header-left">
            <h1>WP ThemeGo 主题管理器</h1>
        </div>
        <div class="header-right">
            <div class="search-box">
                <input type="text" placeholder="搜索...">
                <button class="search-button"><span class="dashicons dashicons-search"></span></button>
            </div>
            <button class="save-button"><span class="dashicons dashicons-saved"></span> 保存更改</button>
        </div>
    </div>

    <!-- 主要内容区域 -->
    <div class="wp-themego-main">
        <!-- 左侧菜单 -->
        <div class="wp-themego-sidebar">
            <ul class="menu-list">
                <li class="menu-item has-submenu active">
                    <a href="#dashboard">
                        <span class="dashicons dashicons-dashboard"></span>
                        控制面板
                        <span class="submenu-arrow dashicons dashicons-arrow-down-alt2"></span>
                    </a>
                    <ul class="submenu">
                        <li class="active"><a href="#dashboard-overview">系统总览</a></li>
                        <li><a href="#dashboard-diagnostic">WP诊断</a></li>
                    </ul>
                </li>
                <li class="menu-item has-submenu">
                    <a href="#theme-management">
                        <span class="dashicons dashicons-admin-appearance"></span>
                        主题管理
                        <span class="submenu-arrow dashicons dashicons-arrow-down-alt2"></span>
                    </a>
                    <ul class="submenu">
                        <li><a href="#theme-list">主题列表</a></li>
                        <li><a href="#theme-install">安装主题</a></li>
                        <li><a href="#theme-backup">主题备份</a></li>
                    </ul>
                </li>
                <li class="menu-item has-submenu">
                    <a href="#theme-settings">
                        <span class="dashicons dashicons-admin-settings"></span>
                        主题设置
                        <span class="submenu-arrow dashicons dashicons-arrow-down-alt2"></span>
                    </a>
                    <ul class="submenu">
                        <li><a href="#general-settings">常规设置</a></li>
                        <li><a href="#style-settings">样式设置</a></li>
                        <li><a href="#advanced-settings">高级设置</a></li>
                    </ul>
                </li>
                <li class="menu-item has-submenu">
                    <a href="#tools">
                        <span class="dashicons dashicons-admin-tools"></span>
                        工具
                        <span class="submenu-arrow dashicons dashicons-arrow-down-alt2"></span>
                    </a>
                    <ul class="submenu">
                        <li><a href="#import-export">导入导出</a></li>
                        <li><a href="#optimization">主题优化</a></li>
                        <li><a href="#diagnostics">诊断工具</a></li>
                    </ul>
                </li>
            </ul>
        </div>

        <!-- 右侧内容区域 -->
        <div class="wp-themego-content">
            <div id="dashboard-overview" class="content-section active">
                <!-- 系统总览内容 -->
                <h2>系统总览</h2>
                
                <!-- 基础统计卡片 -->
                <div class="dashboard-overview-grid">
                    <div class="overview-card">
                        <div class="card-icon"><span class="dashicons dashicons-admin-appearance"></span></div>
                        <div class="card-content">
                            <h3>已安装主题</h3>
                            <p class="number"><?php echo count(wp_get_themes()); ?></p>
                            <p class="trend up">较上月 +2</p>
                        </div>
                    </div>
                    <div class="overview-card">
                        <div class="card-icon"><span class="dashicons dashicons-admin-plugins"></span></div>
                        <div class="card-content">
                            <h3>活跃插件</h3>
                            <p class="number"><?php echo count(get_option('active_plugins')); ?></p>
                            <p class="trend">较上月 0</p>
                        </div>
                    </div>
                    <div class="overview-card">
                        <div class="card-icon"><span class="dashicons dashicons-wordpress"></span></div>
                        <div class="card-content">
                            <h3>WordPress版本</h3>
                            <p class="version"><?php echo get_bloginfo('version'); ?></p>
                            <p class="update-status"><?php echo version_compare(get_bloginfo('version'), '6.0', '>=') ? '已是最新' : '建议更新'; ?></p>
                        </div>
                    </div>
                    <div class="overview-card">
                        <div class="card-icon"><span class="dashicons dashicons-admin-users"></span></div>
                        <div class="card-content">
                            <h3>用户总数</h3>
                            <p class="number"><?php echo count_users()['total_users']; ?></p>
                            <p class="trend up">较上月 +5</p>
                        </div>
                    </div>
                </div>

                <!-- 主题使用统计 -->
                <div class="overview-section">
                    <h3>主题使用统计</h3>
                    <div class="theme-stats-grid">
                        <div class="stats-card">
                            <h4>主题切换频率</h4>
                            <div class="stats-chart">
                                <!-- 这里可以添加图表 -->
                                <div class="placeholder-chart"></div>
                            </div>
                        </div>
                        <div class="stats-card">
                            <h4>主题使用时长</h4>
                            <div class="theme-usage-list">
                                <?php
                                $current_theme = wp_get_theme();
                                ?>
                                <div class="usage-item">
                                    <span class="theme-name"><?php echo $current_theme->get('Name'); ?></span>
                                    <span class="usage-time">使用时长：30天</span>
                                </div>
                                <!-- 可以添加更多主题使用记录 -->
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 系统健康状态 -->
                <div class="overview-section">
                    <h3>系统健康状态</h3>
                    <div class="health-status-grid">
                        <div class="health-card good">
                            <span class="status-icon dashicons dashicons-yes-alt"></span>
                            <div class="status-content">
                                <h4>数据库状态</h4>
                                <p>运行正常，无优化需求</p>
                            </div>
                        </div>
                        <div class="health-card warning">
                            <span class="status-icon dashicons dashicons-warning"></span>
                            <div class="status-content">
                                <h4>缓存状态</h4>
                                <p>建议清理过期缓存</p>
                            </div>
                        </div>
                        <div class="health-card good">
                            <span class="status-icon dashicons dashicons-yes-alt"></span>
                            <div class="status-content">
                                <h4>文件权限</h4>
                                <p>权限设置正确</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="dashboard-diagnostic" class="content-section">
                <!-- WP诊断内容 -->
                <h2>WordPress诊断</h2>
                
                <!-- 系统信息 -->
                <div class="diagnostic-section">
                    <h3>系统信息</h3>
                    <table class="diagnostic-table">
                        <tr>
                            <td>PHP 版本</td>
                            <td><?php echo PHP_VERSION; ?></td>
                            <td class="status">
                                <?php echo version_compare(PHP_VERSION, '7.4', '>=') ? 
                                    '<span class="status-good">良好</span>' : 
                                    '<span class="status-warning">建议升级</span>'; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>MySQL 版本</td>
                            <td><?php echo mysqli_get_client_info(); ?></td>
                            <td class="status">
                                <span class="status-good">良好</span>
                            </td>
                        </tr>
                        <tr>
                            <td>WordPress 内存限制</td>
                            <td><?php echo WP_MEMORY_LIMIT; ?></td>
                            <td class="status">
                                <?php echo (wp_convert_hr_to_bytes(WP_MEMORY_LIMIT) >= 67108864) ? 
                                    '<span class="status-good">良好</span>' : 
                                    '<span class="status-warning">建议增加</span>'; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>最大上传限制</td>
                            <td><?php echo size_format(wp_max_upload_size()); ?></td>
                            <td class="status">
                                <?php echo (wp_max_upload_size() >= 8388608) ? 
                                    '<span class="status-good">良好</span>' : 
                                    '<span class="status-warning">建议增加</span>'; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>服务器软件</td>
                            <td><?php echo $_SERVER['SERVER_SOFTWARE']; ?></td>
                            <td class="status">
                                <span class="status-good">良好</span>
                            </td>
                        </tr>
                        <tr>
                            <td>操作系统</td>
                            <td><?php echo PHP_OS; ?></td>
                            <td class="status">
                                <span class="status-good">良好</span>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- PHP扩展检查 -->
                <div class="diagnostic-section">
                    <h3>PHP扩展检查</h3>
                    <div class="extension-grid">
                        <?php
                        $required_extensions = array(
                            'mysql' => '数据库支持',
                            'gd' => '图像处理',
                            'curl' => '远程请求',
                            'json' => 'JSON支持',
                            'xml' => 'XML支持',
                            'mbstring' => '多字节字符',
                            'zip' => 'ZIP支持',
                            'openssl' => 'SSL支持',
                            'fileinfo' => '文件类型检测',
                            'exif' => '图片信息读取'
                        );

                        foreach ($required_extensions as $ext => $desc) :
                            $installed = extension_loaded($ext);
                            if ($ext === 'mysql') {
                                $installed = extension_loaded('mysqli') || class_exists('mysqli') || function_exists('mysqli_connect');
                            }
                        ?>
                            <div class="extension-card <?php echo $installed ? 'installed' : 'missing'; ?>">
                                <span class="ext-icon dashicons <?php echo $installed ? 'dashicons-yes' : 'dashicons-no'; ?>"></span>
                                <div class="ext-info">
                                    <h4><?php echo $ext; ?></h4>
                                    <p><?php echo $desc; ?></p>
                                </div>
                                <span class="ext-status"><?php echo $installed ? '已安装' : '未安装'; ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- 性能检测 -->
                <div class="diagnostic-section">
                    <h3>性能检测</h3>
                    <div class="performance-grid">
                        <div class="performance-card">
                            <div class="performance-header">
                                <h4>数据库查询</h4>
                                <span class="performance-score good">92</span>
                            </div>
                            <div class="performance-meter">
                                <div class="meter-bar" style="width: 92%"></div>
                            </div>
                            <p class="performance-desc">数据库性能良好，查询响应时间在正常范围内</p>
                        </div>
                        <div class="performance-card">
                            <div class="performance-header">
                                <h4>页面加载</h4>
                                <span class="performance-score warning">78</span>
                            </div>
                            <div class="performance-meter">
                                <div class="meter-bar" style="width: 78%"></div>
                            </div>
                            <p class="performance-desc">页面加载速度尚可，建议优化图片和脚本</p>
                        </div>
                        <div class="performance-card">
                            <div class="performance-header">
                                <h4>缓存效率</h4>
                                <span class="performance-score good">95</span>
                            </div>
                            <div class="performance-meter">
                                <div class="meter-bar" style="width: 95%"></div>
                            </div>
                            <p class="performance-desc">缓存系统工作正常，命中率高</p>
                        </div>
                    </div>
                </div>

                <!-- 安全检查 -->
                <div class="diagnostic-section">
                    <h3>安全检查</h3>
                    <div class="security-checklist">
                        <div class="security-item good">
                            <span class="security-icon dashicons dashicons-shield"></span>
                            <div class="security-content">
                                <h4>SSL证书</h4>
                                <p>已启用HTTPS，证书有效</p>
                            </div>
                        </div>
                        <div class="security-item warning">
                            <span class="security-icon dashicons dashicons-privacy"></span>
                            <div class="security-content">
                                <h4>文件权限</h4>
                                <p>部分目录权限需要调整</p>
                            </div>
                        </div>
                        <div class="security-item good">
                            <span class="security-icon dashicons dashicons-admin-network"></span>
                            <div class="security-content">
                                <h4>管理员登录</h4>
                                <p>登录保护已启用</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="theme-list" class="content-section">
                <!-- 主题列表内容 -->
                <h2>主题列表</h2>
                <div class="themes-grid">
                    <?php
                    $themes = wp_get_themes();
                    foreach ($themes as $theme) :
                        $screenshot = $theme->get_screenshot();
                        $is_active = (get_template() === $theme->get_template());
                    ?>
                        <div class="theme-card<?php echo $is_active ? ' active' : ''; ?>">
                            <div class="theme-screenshot">
                                <?php if ($screenshot) : ?>
                                    <img src="<?php echo esc_url($screenshot); ?>" alt="<?php echo esc_attr($theme->get('Name')); ?>">
                                <?php endif; ?>
                            </div>
                            <div class="theme-info">
                                <h3><?php echo esc_html($theme->get('Name')); ?></h3>
                                <p><?php echo esc_html($theme->get('Description')); ?></p>
                                <div class="theme-actions">
                                    <?php if (!$is_active) : ?>
                                        <button class="button activate-theme" data-theme="<?php echo esc_attr($theme->get_stylesheet()); ?>">
                                            <?php _e('启用主题', 'wp-themego'); ?>
                                        </button>
                                    <?php else : ?>
                                        <span class="active-badge">
                                            <?php _e('当前主题', 'wp-themego'); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- 其他内容区域将根据需要添加 -->
        </div>
    </div>
</div> 