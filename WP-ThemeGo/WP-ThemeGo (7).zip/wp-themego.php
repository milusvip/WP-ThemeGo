<?php
/**
 * Plugin Name: WP-ThemeGo 主题管理器
 * Plugin URI: https://example.com/wp-themego
 * Description: 一个强大的WordPress主题管理插件，提供主题预览、快速切换、备份等功能
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-themego
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Define plugin constants
define('WP_THEMEGO_VERSION', '1.0.0');
define('WP_THEMEGO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WP_THEMEGO_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once WP_THEMEGO_PLUGIN_DIR . 'includes/class-wp-themego.php';

// Initialize the plugin
function run_wp_themego() {
    $plugin = new WP_ThemeGo();
    $plugin->run();
}
add_action('plugins_loaded', 'run_wp_themego');

// Activation hook
register_activation_hook(__FILE__, 'wp_themego_activate');
function wp_themego_activate() {
    // 插件激活时的代码
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'wp_themego_deactivate');
function wp_themego_deactivate() {
    // 插件停用时的代码
} 